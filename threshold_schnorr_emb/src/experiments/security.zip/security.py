from __future__ import annotations
#1.低位均匀性实验；2.掉线实验；3.伪造实验
import logging
import secrets
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List

import numpy as np
from scipy import stats
from tqdm import tqdm
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from src.experiments.common import single_trial
from src.scheme.setup import setup as scheme_setup
from src.scheme.sign_emb import sign_emb
from src.scheme.verify import verify
from src.scheme.types import Signature
from src.crypto.curve_utils import get_order, get_generator, random_scalar, scalar_mult
from src.utils.io_utils import save_rows_csv
from src.utils.plot_utils import setup_style, save_fig

# 安全性实验：1. 低位均匀性；2. 掉线容忍；3. 伪造率
def run_security(cfg: Dict[str, Any], out: Path, logger: logging.Logger) -> None:
    exp = cfg.get("security", {})

    # =========================================================
    # 低位均匀性实验
    # =========================================================
    logger.info("Security Part 1: Low-bit uniformity")#安全性第一部分：低位均匀性实验
    #参数设置
    unif_cfg = exp.get("uniformity", {})#uniformity 实验的配置参数，包含 n（总节点数）、t（参与签名的节点数）、Nmax（最大重试次数）、L_values（要测试的低位长度列表）和 num_samples（基础样本数量）
    n = unif_cfg.get("n", 5)
    t = unif_cfg.get("t", 3)
    Nmax = unif_cfg.get("Nmax", 4096)
    Ls = unif_cfg.get("L_values", [1, 2, 4, 6])
    base_samples = unif_cfg.get("num_samples", 5000)

    # 汇总统计结果：每个 L 一行
    unif_rows: List[Dict[str, Any]] = []

    # 原始 pattern 统计结果：每个 L 下的每个 pattern 一行
    pattern_rows: List[Dict[str, Any]] = []

    # 缓存同一轮实验数据，用于后续生成整体 grid 图
    # 这样不会为了画图重新跑第二轮实验
    uniformity_plot_data: Dict[int, Dict[str, Any]] = {}

    setup_style()

    # =========================================================
    # 只跑一轮 Uniformity 实验
    # 这一轮同时完成：
    # 1. 采样
    # 2. 统计 chi2 / p-value / entropy
    # 3. 保存每个 pattern 的 count / empirical_probability
    # 4. 缓存数据用于整体 Figure 5
    # =========================================================
    for L in tqdm(Ls, desc="Uniformity"):

        target_samples = int(base_samples * (2 ** max(L - 2, 0)))
        #调用scheme_setup函数生成预设的密钥和共享信息，参数是 t（参与签名的节点数）、n（总节点数）和 L（要嵌入的信息位数）
        sr = scheme_setup(t, n, L)
        counts = Counter()#计数器，用于统计每个低位模式（0 到 2^L - 1）出现的次数
        collected = 0#成功收集的签名数
        attempts = 0#总尝试次数
        max_attempts = target_samples * 20
        #在模拟中，每次尝试都调用 single_trial 函数生成一个签名，并检查签名是否成功且包含 s 字段的低 L 位信息。如果成功，则统计对应的低位模式出现次数，直到收集到足够的样本或达到最大尝试次数。
        while collected < target_samples and attempts < max_attempts:#如果收集的样本数不足且尝试次数未超过最大限制，则继续尝试生成签名
            attempts += 1
            #调用single_trial函数执行一次完整的签名-验签-提取流程，传入预设的密钥和共享信息、参与者数量 t、嵌入信息长度 L 和最大重试次数 Nmax，返回一个包含签名结果和相关统计信息的字典 row
            # 对应common.py的single_trial函数
            row = single_trial(sr, t, L, Nmax)
            #统计成功生成的签名，并提取签名对象中 s 字段的低 L 位信息，更新计数器 counts 中对应模式的出现次数，同时更新成功收集的样本数 collected
            if row["success"] and "s_low_bits" in row:
                counts[row["s_low_bits"]] += 1
                collected += 1
        #统计完成后，计算总的模式数量 num_bins（即 2^L），构造一个 observed 列表，包含每个模式的出现次数，如果成功收集了样本，则计算每个模式的期望出现次数 expected，并使用 scipy 的 chisquare 函数计算 chi2 统计量和 p-value，以评估观察到的分布与均匀分布之间的差异。同时计算经验熵 emp_entropy 和熵比率 entropy_ratio，以量化分布的随机性。
        num_bins = 2 ** L
        observed = [counts.get(i, 0) for i in range(num_bins)]
        #计算卡方统计量和 p-value，评估观察到的分布与均匀分布之间的差异
        if collected > 0:
            expected = [collected / num_bins] * num_bins#理论均匀分布下每个模式的期望出现次数
            chi2_stat, chi2_p = stats.chisquare(observed, expected)
        else:
            chi2_stat, chi2_p = 0.0, 1.0
        #计算经验熵和熵比率，量化分布的随机性
        probs = np.array(observed, dtype=float)
        if collected > 0:
            probs /= collected

        probs_nonzero = probs[probs > 0]

        emp_entropy = (
            -np.sum(probs_nonzero * np.log2(probs_nonzero))
            if len(probs_nonzero) > 0
            else 0.0
        )

        entropy_ratio = emp_entropy / L if L > 0 else 0.0

        # 保存每个 L 的汇总统计结果
        unif_rows.append({
            "L": L,
            "samples": collected,
            "attempts": attempts,
            "num_bins": num_bins,
            "chi2": chi2_stat,
            "p_value": chi2_p,
            "entropy": emp_entropy,
            "entropy_ratio": entropy_ratio,
        })

        # =====================================================
        # 保存每个 pattern 的原始统计数据
        # 这就是 Origin 画图需要的 CSV
        # =====================================================
        uniform_probability = 1.0 / num_bins
        expected_count = collected / num_bins if collected > 0 else 0.0

        for pattern, count in enumerate(observed):
            empirical_probability = count / collected if collected > 0 else 0.0

            pattern_rows.append({
                "L": L,
                "samples": collected,
                "pattern": pattern,
                "count": count,
                "empirical_probability": empirical_probability,
                "uniform_probability": uniform_probability,
                "expected_count": expected_count,
                "difference": empirical_probability - uniform_probability,
                "ratio_to_uniform": (
                    empirical_probability / uniform_probability
                    if uniform_probability > 0
                    else 0.0
                ),
            })

        # 缓存当前 L 的数据，用于后面生成整体 grid 图
        uniformity_plot_data[L] = {
            "collected": collected,
            "num_bins": num_bins,
            "observed": observed,
        }

        logger.info(
            "L=%s, samples=%s, attempts=%s, chi2=%.6f, p=%.6f, entropy_ratio=%.8f",
            L,
            collected,
            attempts,
            chi2_stat,
            chi2_p,
            entropy_ratio,
        )

    # 保存汇总统计 CSV
    save_rows_csv(
        unif_rows,
        out / "tables" / "security_uniformity.csv"
    )

    # 保存每个 pattern 的 count / probability CSV
    save_rows_csv(
        pattern_rows,
        out / "tables" / "security_uniformity_patterns.csv"
    )

    # =========================================================
    # 论文级整体 Grid 图
    # 只使用上面这一轮实验缓存的数据，不重新跑实验
    # =========================================================
    logger.info("Plotting grid figure from one-round uniformity data")

    num_L = len(Ls)
    cols = 2
    rows = (num_L + 1) // 2

    fig, axes = plt.subplots(rows, cols, figsize=(10, 4 * rows))

    if rows == 1:
        axes = np.array([axes])

    axes = axes.flatten()

    last_idx = -1

    for idx, L in enumerate(Ls):
        last_idx = idx

        data = uniformity_plot_data[L]
        collected = data["collected"]
        num_bins = data["num_bins"]
        observed = data["observed"]

        ax = axes[idx]

        if collected > 0:
            x = np.arange(num_bins)
            empirical_probs = [o / collected for o in observed]
            uniform_probs = [1 / num_bins] * num_bins

            ax.bar(
                x,
                empirical_probs,
                width=0.8,
                alpha=0.8,
                label="Empirical"
            )

            ax.plot(
                x,
                uniform_probs,
                linestyle="--",
                marker="o",
                label="Uniform"
            )

        ax.set_title(f"L = {L}")
        ax.set_xlabel("Low-bit pattern")
        ax.set_ylabel("Probability")
        ax.grid(True, alpha=0.3)

        if idx == 0:
            ax.legend()

    for j in range(last_idx + 1, len(axes)):
        fig.delaxes(axes[j])

    fig.suptitle("Low-bit Pattern Uniformity Across Different L", fontsize=14)
    plt.tight_layout()

    save_fig(
        fig,
        out / "figures" / "security_uniformity_grid.png"
    )

    # =========================================================
    # Part 2: 掉线容忍实验
    # =========================================================
    logger.info("Security Part 2: Dropout")

    drop_trials = 500
    drop_rows = []

    sr = scheme_setup(3, 5, 2)#n=5，t=3，L=2

    for online in range(3, 6):#在线参与者数量从 t=3 到 n=5 变化，测试掉线容忍能力
        participants = list(range(1, online + 1))#参与者 ID 从 1 到 online
        ok = 0#成功计数器：在 drop_trials 次试验中，成功生成并验证签名的次数

        for _ in range(drop_trials):#每次试验中，随机生成消息 m 和嵌入信息 M，然后调用 sign_emb 进行签名，最后验证签名是否成功
            m = secrets.token_bytes(32)
            M = secrets.randbelow(4)

            res = sign_emb(
                m,
                participants,
                sr.shares,
                sr.share_pks,
                sr.pk,
                sr.Kext,
                M,
                2,
                256
            )

            if res.success and verify(m, sr.pk, res.signature):
                ok += 1

        drop_rows.append({
            "online": online,
            "trials": drop_trials,
            "success": ok,
            "rate": ok / drop_trials if drop_trials > 0 else 0.0,
        })

    save_rows_csv(
        drop_rows,
        out / "tables" / "security_dropout.csv"
    )

    # =========================================================
    # Part 3: 伪造实验,测试攻击者在没有任何私钥信息的情况下，随机生成一个签名并验证成功的概率
    # =========================================================
    logger.info("Security Part 3: Forgery")#logger 输出安全性第三部分：伪造实验

    forge_trials = 1000
    forge_pass = 0#伪造成功的次数

    sr = scheme_setup(3, 5, 2)#n=5，t=3，L=2
    q = get_order()
    G = get_generator()

    for _ in range(forge_trials):
        m = secrets.token_bytes(32)
    
        fake_sig = Signature( #随机生成一个签名，R 是 G 的随机倍数，s 是随机标量
            R=scalar_mult(random_scalar(), G),
            s=random_scalar()
        )

        if verify(m, sr.pk, fake_sig):#验证这个随机生成的签名，如果验证成功则认为是一次伪造成功
            forge_pass += 1

    save_rows_csv([{
        "trials": forge_trials,
        "success": forge_pass,
        "forge_rate": forge_pass / forge_trials if forge_trials > 0 else 0.0,
    }], out / "tables" / "security_forgery.csv")

    logger.info("Security experiment complete.")